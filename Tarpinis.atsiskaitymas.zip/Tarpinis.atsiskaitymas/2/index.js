const MyElement = document.createElement("div")
document.body.append(MyElement)
MyElement.setAttribute("id", "cube");
