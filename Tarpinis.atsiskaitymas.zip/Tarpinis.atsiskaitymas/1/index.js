// 1.1 
 cars.filter((cars) => {
    return cars.Miles_per_Gallon ;    
   })

// 1.2
cars.filter((cars) => {
  return  !cars.Miles_per_Gallon  ;    
 })

// 1.3 
 cars.filter((cars) => {
 return cars.Miles_per_Gallon >= 15 && cars.Cylinders === 8  ;    
})

//1.4


//1.5
cars.sort((a,b) => {
  return a.Weight_in_lbs - b.Weight_in_lbs
});


//1.6
  cars.some((cars) => {
    return cars.origin === "USA" ;    
   }) 